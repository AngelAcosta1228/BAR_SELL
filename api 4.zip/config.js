let config = {}

config.puerto = 3000
config.bd = "pruebaibero04"
config.origin = [
    "http://localhost:4200"
]

// config.maxage = 60000
// config.palabraclave = "bd0g79b09uhga89gbdf"
// config.nombrecookie = "haperuq"

module.exports.config = config