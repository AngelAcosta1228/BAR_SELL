const usuariosModel = require("../modelos/usuariosModel.js").usuariosModel;
const usuariosController = {};

usuariosController.save = function(request, response) {
    let { email, password, nombre, estado, } = request.body;

    // Validar email
    if (!email) {
        return response.json({ state: false, mensaje: "el campo email es obligatorio", campo: "email" });
    }
    //validar password
    if (!password) {
        return response.json({ state: false, mensaje: "el campo password es obligatorio", campo: "password" });
    }

    // Validar nombre
    if (!nombre) {
        return response.json({ state: false, mensaje: "el campo nombre es obligatorio", campo: "nombre" });
    }
    if (nombre.length < 4) {
        return response.json({ state: false, mensaje: "el campo nombre debe contener minimo 4 caracteres", campo: "nombre" });
    }
    if (nombre.length > 50) {
        return response.json({ state: false, mensaje: "el campo nombre debe contener maximo 50 caracteres", campo: "nombre" });
    }

    // Validar estado
    if (estado === undefined || estado === null) {
        return response.json({ state: false, mensaje: "el campo estado es obligatorio", campo: "estado" });
    }
    if (typeof estado === 'string') {
        if (estado.toLowerCase() === "true") {
            estado = true;
        } else if (estado.toLowerCase() === "false") {
            estado = false;
        } else {
            return response.json({ state: false, mensaje: "el campo estado debe ser true o false", campo: "estado" });
        }
    }

    // Crear objeto post después de todas las validaciones
    let post = { email, password, nombre, estado };

    usuariosModel.buscaremail(post, function(resultado) {
        if (resultado.posicion == -1) {
            usuariosModel.crear(post, function(respuesta) {
                if (respuesta.state === true) {
                    return response.json({ state: true, mensaje: "Usuario creado correctamente" });
                } else {
                    return response.json({ state: false, mensaje: "Error al guardar" });
                }
            });
        } else {
            return response.json({ state: false, mensaje: "el email ya existe" });
        }
    });
};

usuariosController.listar = function(request, response) {
    usuariosModel.listar(null, function(respuesta) {
        response.json(respuesta);
    });
};

usuariosController.listarid = function(request, response) {

    let post = { 
        _id:request.body._id,
    }

    if (!post._id) {
        return response.json({ state: false, mensaje: "el campo id es obligatorio", campo: "_id" });
    }

    usuariosModel.listarid(post, function(respuesta) {
        response.json(respuesta);
    });
};

usuariosController.update = function(request, response) {
    let post = { 
        _id:request.body._id,
        nombre:request.body.nombre,
        estado:request.body.estado
    }

    if (!post._id) {
        return response.json({ state: false, mensaje: "el campo id es obligatorio", campo: "_id" });
    }
    if (!post.nombre) {
        return response.json({ state: false, mensaje: "el campo nombre es obligatorio", campo: "nombre" });
    }
    if (post.estado === undefined || post.estado === null) {
        return response.json({ state: false, mensaje: "el campo estado es obligatorio", campo: "estado" });
    }

    usuariosModel.update(post, function(respuesta) {
        if (respuesta.state == true) {
            response.json({ state: true, mensaje: "se actualizo el elemento correctamente" });
        } else {
            response.json({ state: false, mensaje: "se presento un error al actualizar el elemento", error: respuesta });
        }
    });
};

usuariosController.delete = function(request, response) {
    let post = { 
        _id:request.body._id,
        nombre:request.body.nombre,
        estado:request.body.estado
    }

    if (!post._id) {
        return response.json({ state: false, mensaje: "el campo id es obligatorio", campo: "_id" });
    }

    usuariosModel.delete(post, function(respuesta) {
        if (respuesta.state == true) {
            response.json({ state: true, mensaje: "se elimino el elemento correctamente" });
        } else {
            response.json({ state: false, mensaje: "se presento un error al eliminar el elemento", error: respuesta });
        }
    });
};

usuariosController.login = function(request, response) {

    let post = { 
        email: request.body.email,
        password: request.body.password,
    }

    if (!post.email) {
        return response.json({ state: false, mensaje: "el campo email es obligatorio", campo: "email" });
    }
    if (!post.password) {
        return response.json({ state: false, mensaje: "el campo password es obligatorio", campo: "password" });
    }

    usuariosModel.login(post, function(respuesta) {
        console.log(respuesta)
        if (respuesta.state == true){
            if(respuesta.data.length == 0){
                response.json({state: false, mensaje: "Error en las credenciales de acceso"})
            } else {
                request.session.nombre = respuesta.data[0].nombre
                response.json({state: false, mensaje: "Bienvenido " + respuesta.data[0].nombre })
            }
        } else {
            response.json({state: false, mensaje: "Error en las credenciales de acceso"})
        } 
    })

};




module.exports.usuariosController = usuariosController;





